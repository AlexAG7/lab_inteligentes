
import java.util.ArrayList;
import java.util.List;

public class RushHour {
    
    
    private final static ArrayList<Vehiculo> vehiculos = new ArrayList<>();
    private final static int TAMANIO_MATRIZ = 6;
    private final static int FILA_SALIDA = 2;


    public static void main(String[] args) {

        String cadena = "IBBoooIoooDDJAAoooJoKEEMooKooMGGHHHM";
        comprobarCadena(cadena);

        mostrarMatriz(vehiculos);



        System.out.println("Cadena final: " + cadena);



        // if (args.length == 0) {
        //     System.out.println("No se proporcionó ninguna acción.");
        //     return;
        // }
        
        // String accion = args[0]; // <acción>
        
        // switch (accion) {
        //     case "mover":
        //         // aquí podrías llamar a un método mover con args[1..n] como parámetros
        //         System.out.println("Ejecutando mover con parámetros...");
        //         break;
        //     case "reiniciar":
        //         System.out.println("Ejecutando reiniciar...");
        //         break;
        //     default:
        //         System.out.println("Acción desconocida: " + accion);
        // }


        
    }

    public static boolean comprobarCadena(String cadena){



// Comprobar al leer la cadena
        // x Si el tamaño del string no se corresponde con un nivel de 6x6.



// Comprobar vehiculo por vehiculo
        // Si hay vehículos con la misma letra duplicados (deben estar separados por una casilla vacía). ***
        // Vehículo con longitud mayor que 3 o menor que 2.
        // Si el vehículo rojo no está situado horizontalmente.
        // Si el vehículo rojo no está en la fila de salida.
        // x No está el vehículo rojo ('A') en el string.
        // Si el string contiene caracteres no válidos (no ('A'-'Z' u 'o')).


// Si no hay error el resultado a devolver es 0.



        boolean estaRojoValido = false; // Para comprobar que existe el coche rojo
        boolean esCadenaValida = true;
        Vehiculo vehiculo_actual;
        String id_actual;
        String[] caracteres = cadena.split("");

        // Comprobar que se trata de una matriz 6x6
        if (caracteres.length > 36) {
            esCadenaValida = false;
        } 

        else {

            // Iterar cadena y construir vehiculos SIEMPRE QUE LA CADENA SIGA SIENDO VÁLIDA
            for (int i = 0; i<caracteres.length && esCadenaValida; i++)  { // Añado el && esCadenaValida para cortar el bucle se se detecta como erronea la cadena

              // Si el caracter no es una x (uso la x para marcar las posiciones que ya he tenido en cuenta) y no es una casilla vacia
                if ((!caracteres[i].equals("x")) && (!caracteres[i].equals("o"))) { 

                        // Construimos un nuevo vehiculo.


                        construirVehiculo(caracteres, i);


                        // La fila inicial sigue una relacion i / 6
                        // La col inicial sigue una relacion i mod 6

                        id_actual = caracteres[i];

                        //          ("id", "fila_inicial", "col_inicial")
                        vehiculo_actual = new Vehiculo(id_actual, i/6, i%6);

                        // Ya sabemos la pos inicial, ahora comprobamos si el vehiculo se extiende vertical u horizontalmente

                            // Comprobamos si se extiende horizontalmente
                            while(id_actual.equals(caracteres[i+1])){

                                // Actualizamos longitud en el vehiculo
                                vehiculo_actual.incrementarLongitud();

                                // "Tachamos" el caracter de la cadena para no tenerlo en cuenta
                                caracteres[i] = "x";

                                vehiculo_actual.setHorizontal(); // Establecemos la orientacion {HORIZONTAL}

                                i++; // Pasamos al siguiente caracter
                
                            }

                            // Comprobamos si se extiende verticalmente
                            if (vehiculo_actual.getLongitud()==1) { // Si no se extiende horizontal, comprobamos si se extiende verticalmente
                                
                                // ******** pte. hacerlo general *********

                                int ptr = 6; // puntero para apuntar a la siguiente posicion verticalmente 

                                while(((i+ptr)<36)&&(id_actual.equals(caracteres[i+ptr]))){ // Si coincide con el caracter de la misma col pero una fila mas abajo...

                                // Actualizamos longitud en el vehiculo
                                vehiculo_actual.incrementarLongitud();

                                // "Tachamos" el caracter que acabamos de tener en cuenta para no contarlo dos veces
                                caracteres[i+ptr] = "x";

                                vehiculo_actual.setVertical(); // Establecemos la orientacion {VERTICAL}

                                ptr = ptr+6; // Pasamos al siguiente caracter (desplazandonos verticalmente)

                                }
                            }


                        // System.out.println("Vehiculo construido: ");
                        // System.out.println("ID: " + vehiculo_actual.getId() + " fila: " + vehiculo_actual.getFila() + " col: " + 
                        // vehiculo_actual.getColumna() + " longitud: " + vehiculo_actual.getLongitud() + " orientacion: " + vehiculo_actual.getOrientacion());


                        // PENDIENTE COMPROBAR VEHICULO para determinar si es valido
                        
                        if (vehiculo_actual.getId().equals("A")) { // Si es rojo

                            if ((vehiculo_actual.getFila()==FILA_SALIDA) && (vehiculo_actual.esHorizontal())) { // Si el rojo esta en la fila de salida y horizontalmente
                                estaRojoValido = true; // El rojo existe
                            }
                        }




                        // Añadimos al listado de vehiculos
                        vehiculos.add(vehiculo_actual);

                } 
            }
        }

        return esCadenaValida;
    }

    public static void mostrarMatriz(ArrayList<Vehiculo> vehiculos) {
    String[][] tablero = new String[6][6];

    // 1. Rellenar con "."
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j < 6; j++) {
            tablero[i][j] = "o";
        }
    }

    // 2. Colocar los vehículos
    for (Vehiculo v : vehiculos) {
    int fila = v.getFila();
    int col = v.getColumna();

    for (int k = 0; k < v.getLongitud(); k++) {
        if (v.esHorizontal()) {
            if (col + k < 6) {  // aseguramos que no se pase
                tablero[fila][col + k] = v.getId();
            } else {
                System.out.println("⚠ Vehículo " + v.getId() + " se sale del tablero. - Este vehiculo tiene posicion " + v.getOrientacion());
            }
        } else { // VERTICAL
            if (fila + k < 6) { // aseguramos que no se pase
                tablero[fila + k][col] = v.getId();
            } else {
                System.out.println("⚠ Vehículo " + v.getId() + " se sale del tablero.");
            }
        }
    }
}


    // 3. Mostrar por pantalla
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j < 6; j++) {
            System.out.print(tablero[i][j] + " ");
        }
        System.out.println();
    }
}




    public static boolean esCaracterValido(String caracter){

        boolean esValido = false;
        String c_validos = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

        // Si es "o" o está dentro del listado de caracteres válidos, lo marcamos como válido
        if (caracter.equals("o")) {
            esValido = true;
        } else {

            if (c_validos.contains(caracter)) {
                esValido = true;
            }
        }

        return esValido;
    }


}
