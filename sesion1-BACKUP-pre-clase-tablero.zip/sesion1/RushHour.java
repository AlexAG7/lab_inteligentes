
import java.util.ArrayList;

public class RushHour {
    
    
    private final static ArrayList<Vehiculo> vehiculos = new ArrayList<>();
    private final static int FILA_SALIDA = 2;
    private static String[] caracteres;


    public static void main(String[] args) {

        String cadena = "ooooBBBooDDMAooooMAoKEEMIoKLFFIoKLoo"; 
        caracteres = cadena.split("");
        int estadoErrorCadena = 0;
        estadoErrorCadena = comprobarCadena(cadena, caracteres);
        System.out.println("codigo: " + estadoErrorCadena);
        
         mostrarMatriz(vehiculos);

        if (args.length == 0) {
            System.out.println("No se proporcionó ninguna acción.");
            return;
        }
        
        String accion = args[0]; // <acción>
        
         switch (accion) {
             case "verify":
                 // Verificar cadena
                 System.out.println("Ejecutando verify");
                 // String cadena = args[2]; 
                 caracteres = cadena.split("");
                 estadoErrorCadena = comprobarCadena(cadena, caracteres);
                 System.out.println(estadoErrorCadena);
                 break;

             case "question":
                 System.out.println("Ejecutando question");
                 break;
             default:
                 System.out.println("No has indicado una accion valida");
         }


        
    }

    public static int comprobarCadena(String cadena, String[] caracteres){

        // 0: Todo correcto , 3: No existe rojo, 4: Existe rojo pero no fila salida, 5: Existe rojo pero no es horizontal
        int estaRojoValido = 3; 
        int estadoErrorCadena = 0;
        Vehiculo vehiculo_actual;

        // Comprobar que se trata de una matriz 6x6 (36 casillas)
        if (caracteres.length != 36) {
            estadoErrorCadena = 1; // ERROR (1) : el tamaño del string no se corresponde con un nivel de 6x6.
        } 

        else {

            // Iterar cadena y construir vehiculos SIEMPRE QUE LA CADENA SIGA SIENDO VALIDA
            for (int i = 0; i<caracteres.length && estadoErrorCadena==0; i++)  { // Añado el && estadoErrorCadena para cortar el bucle se se detecta como erronea la cadena

              // Si el caracter no es una "o" (uso la "o" para marcar las posiciones que ya he tenido en cuenta)
                if ((!caracteres[i].equals("o"))) { 

                    // Construimos un nuevo vehiculo.
                        vehiculo_actual = construirVehiculo(caracteres, i);

                    // COMPROBACIONES....
                        // Comprobaciones coche rojo (CODIGOS: 3, 4, 5)
                        if (estaRojoValido==3 && vehiculo_actual.getId().equals("A")) { // Si aun no lo hemos encontrado --> seguimos buscando
                            estaRojoValido = comprobarRojoValido(vehiculo_actual, estaRojoValido);
                        }

                        // Comprobaciones generales
                        estadoErrorCadena = comprobarVehiculo(vehiculo_actual, estadoErrorCadena);
                     
                    // Añadimos al listado de vehiculos
                    vehiculos.add(vehiculo_actual);

                } 
            }

            // Si no hay rojo o hay rojo pero no es valido --> cadena no valida
            if (estaRojoValido!=0 && estadoErrorCadena==0) { // Si hay un problema con el rojo y los demas vehiculos estan bien
                 estadoErrorCadena = estaRojoValido; // Nuestro estado de error se corresponde al del rojo
             }

        }

        return estadoErrorCadena;
    }

    public static int comprobarRojoValido(Vehiculo vehiculo_actual, int estado_actual){

                if (vehiculo_actual.getFila() != FILA_SALIDA) return 4; // Si existe pero no esta en la fila de salida (4)
                if (!vehiculo_actual.esHorizontal()) return 5; // Si no es horizontal
                return 0; // Todo esta bien
    }

    public static int comprobarVehiculo(Vehiculo vehiculo_actual, int estado_actual){


        // Si esta fuera de el rango de longitudes[2, 3] : ERROR 6
         if (vehiculo_actual.getLongitud()<2 || vehiculo_actual.getLongitud()>3) {
             estado_actual = 6;
         }

        // Si el id es un caracter no valido: ERROR 2
         if (!vehiculo_actual.tieneIdValido()) {
             estado_actual = 2;
         }

        // Comprobar si ya existe un coche con ese id
         if(vehiculoYaExiste(vehiculo_actual.getId())){

            estado_actual = 7;

         }
    
        return estado_actual;


    }

    // Devuelve true si ya existe un vehiculo con ese id
    public static boolean vehiculoYaExiste(String id){

        boolean existe = false;

        for (Vehiculo vehi : vehiculos) { 

            if (vehi.getId().equals(id)) { // Si ya existe un vehiculo con ese ID
                existe = true;
            }
        }

        return existe; 
    }




    public static void mostrarMatriz(ArrayList<Vehiculo> vehiculos) {
        String[][] tablero = new String[6][6];

        // 1. Rellenar con "."
        for (int i = 0; i < 6; i++) {
            for (int j = 0; j < 6; j++) {
                tablero[i][j] = "o";
            }
        }

        // 2. Colocar los vehículos
        for (Vehiculo v : vehiculos) {
        int fila = v.getFila();
        int col = v.getColumna();

        for (int k = 0; k < v.getLongitud(); k++) {
            if (v.esHorizontal()) {
                if (col + k < 6) {  // aseguramos que no se pase
                    tablero[fila][col + k] = v.getId();
                } else {
                    System.out.println("⚠ Vehículo " + v.getId() + " se sale del tablero. - Este vehiculo tiene posicion " + v.getOrientacion());
                }
            } else { // VERTICAL
                if (fila + k < 6) { // aseguramos que no se pase
                    tablero[fila + k][col] = v.getId();
                } else {
                    System.out.println("⚠ Vehículo " + v.getId() + " se sale del tablero.");
                }
            }
        }
}


    // 3. Mostrar por pantalla
    for (int i = 0; i < 6; i++) {
        for (int j = 0; j < 6; j++) {
            System.out.print(tablero[i][j] + " ");
        }
        System.out.println();
    }
}


public static Vehiculo construirVehiculo(String[] caracteres, int i) {

    String id_actual = caracteres[i];
    Vehiculo vehiculo_actual = new Vehiculo(id_actual, i / 6, i % 6);

    // Comprobamos si el vehiculo se exitnede horizontalmente
    boolean extendido = extenderVehiculoHorizontal(vehiculo_actual, caracteres, i);

    // Si no se extendió en horizontal, se extiende verticalmente
    if (!extendido) {
        extenderVehiculoVertical(vehiculo_actual, caracteres, i);
    }

    System.out.println(vehiculo_actual.toString()); // DEBUG
    return vehiculo_actual;
}

private static boolean extenderVehiculoHorizontal(Vehiculo vehiculo, String[] caracteres, int i) {
    String id = vehiculo.getId();
    boolean extendido = false;

    // i + 1 < caracteres.length ::::: Para evitar Index out of bounds
    // (i % 6) != 5 :::: Para evitar cambiar de fila  
    while (i + 1 < caracteres.length && (i % 6) != 5 && id.equals(caracteres[i + 1])) {
        vehiculo.incrementarLongitud();
        caracteres[i + 1] = "o";   // tachar ese hueco
        vehiculo.setHorizontal();
        i++;
        extendido = true;
    }

    return extendido;
}

private static void extenderVehiculoVertical(Vehiculo vehiculo, String[] caracteres, int i) {
    String id = vehiculo.getId();
    int ptr = 6;

    while (i + ptr < caracteres.length && id.equals(caracteres[i + ptr])) {
        vehiculo.incrementarLongitud();
        caracteres[i + ptr] = "o"; // tachamos ese hueco
        vehiculo.setVertical();
        ptr += 6;
    }
}



    public static Vehiculo construirVehiculo2(String[] caracteres, int i){
        
        Vehiculo vehiculo_actual;
        String id_actual;
                        // La fila inicial sigue una relacion i / 6
                        // La col inicial sigue una relacion i mod 6

                        id_actual = caracteres[i];

                        //("id", "fila_inicial", "col_inicial")
                        vehiculo_actual = new Vehiculo(id_actual, i/6, i%6);

                        // Ya sabemos la pos inicial, ahora comprobamos si el vehiculo se extiende vertical u horizontalmente

                            // Comprobamos si se extiende horizontalmente && NO nos salimos del tablero
                            while(i + 1 < caracteres.length && id_actual.equals(caracteres[i+1])){

                                // Actualizamos longitud en el vehiculo
                                vehiculo_actual.incrementarLongitud();

                                // "Tachamos" el caracter de la cadena para no tenerlo en cuenta
                                caracteres[i+1] = "o";

                                vehiculo_actual.setHorizontal(); // Establecemos la orientacion {HORIZONTAL}

                                i++; // Pasamos al siguiente caracter
                
                            }

                            // Comprobamos si se extiende verticalmente
                            if (vehiculo_actual.getLongitud()==1) { // Si no se extiende horizontal, comprobamos si se extiende verticalmente
                                
                                int ptr = 6; // puntero para apuntar a la siguiente posicion verticalmente 

                                while(((i+ptr)<36)&&(id_actual.equals(caracteres[i+ptr]))){ // Si coincide con el caracter de la misma col pero una fila mas abajo...

                                // Actualizamos longitud en el vehiculo
                                vehiculo_actual.incrementarLongitud();

                                // "Tachamos" el caracter que acabamos de tener en cuenta para no contarlo dos veces
                                caracteres[i+ptr] = "o";

                                vehiculo_actual.setVertical(); // Establecemos la orientacion {VERTICAL}

                                ptr = ptr+6; // Pasamos al siguiente caracter (desplazandonos verticalmente)

                                }
                            }
        

                            System.out.println(vehiculo_actual.toString());

                        return vehiculo_actual;

    }


}
