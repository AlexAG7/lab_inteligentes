

public class Vehiculo {

    public enum Orientacion { HORIZONTAL, VERTICAL }

    private String id;               // Identificador (ej: "A", "B" ...)
    private int fila;                // Fila de la casilla inicial (0-5)
    private int columna;             // Columna de la casilla inicial (0-5)
    private int longitud;            // 2 = coche, 3 = camión
    private Orientacion orientacion; // Dirección del vehículo

    public Vehiculo(String id, int fila, int columna) {
        this.id = id;
        this.fila = fila;
        this.columna = columna;
        this.longitud = 1; // Longitud minima cuando se construye (1 casilla)
    }

    // --- Getters ---
    public String getId() {
        return id;
    }

    public int getFila() {
        return fila;
    }

    public void incrementarLongitud(){ // Incrementa en 1 la longitud
        this.longitud++;
    } 
  

    public int getColumna() {
        return columna;
    }

    public int getLongitud() {
        return longitud;
    }

    public Orientacion getOrientacion(){
        return this.orientacion;
    }

    public boolean esHorizontal() {
        return this.orientacion == Orientacion.HORIZONTAL;
    }

    public void setHorizontal( ) {
        this.orientacion = Orientacion.HORIZONTAL;
    }

     public void setVertical( ) {
        this.orientacion = Orientacion.VERTICAL;
    }

    @Override
    public String toString() {
        return String.format("Vehiculo{id='%s', fila=%d, columna=%d, longitud=%d, orientacion=%s}",
                id, fila, columna, longitud, orientacion);
    }
}
